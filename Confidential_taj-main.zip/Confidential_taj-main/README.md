<center>
 
# The National Scholarship Portal

</center>

**The National Scholarships Portal (NSP) is a digital platform introduced by the Government of India to streamline the scholarship application and disbursement process for various centrally sponsored scholarships** The portal serves as a one-stop destination for students across the country to apply for scholarships offered by different government departments, ministries, and state governments.

**The NSP was launched to ensure transparency, efficiency, and accessibility in the scholarship process.** 

**It aims to provide financial assistance to meritorious and economically disadvantaged students pursuing higher education in India.** By centralizing the scholarship application process, the NSP simplifies the procedure for students, making it easier for them to apply for multiple scholarships through a single online platform.

#### Key features and benefits of the National Scholarships Portal include:

1. **Centralized Application Process:** The NSP provides a single platform for students to apply for various scholarships offered by different governments.

2. **Multiple Scholarship Schemes:** The portal covers a wide range of scholarship schemes, including pre-matric, post-matric, and merit-based scholarships, catering to students from different academic backgrounds and levels of education.

3. **Transparency and Accountability:** The NSP ensures transparency in the scholarship process by providing real-time updates on the status of applications, disbursement details, and scholarship amounts. It helps students track their applications and know the outcome promptly.

4. **Timely Disbursement:** With a streamlined online application process, the NSP aims to ensure timely disbursal of scholarship funds directly into the bank accounts of eligible students, reducing delays and paperwork.

5. **User-Friendly Interface:** The portal is designed to be user-friendly and accessible, making it easy for students to navigate, register, and apply for scholarships without any technical hassles.

6. **Mobile Application:** The NSP offers a mobile application, enabling students to access the portal and apply for scholarships using their smartphones, increasing accessibility, especially in rural areas.

7. **Dashboards for Authorities:** Apart from students, the NSP provides dedicated dashboards for institutions and state authorities to manage scholarship applications, verify documents, and facilitate the disbursement process.

8. **Digitization of Documents:** The portal allows students to upload and submit their documents online, reducing the need for physical paperwork and making the process more eco-friendly.

The National Scholarships Portal plays a crucial role in promoting inclusive education and empowering deserving students to pursue their academic aspirations without financial constraints. By providing a transparent and efficient platform, the NSP contributes to the government's vision of building a skilled and educated workforce, which is vital for the nation's growth and development.



#### <span style="color:grey"> Key challenges or Problem areas / Pain points</span>

1. Manual war deployments are often slow and infrequent due to time-consuming manual testing and deployment processes.

2. In larger development teams, integrating code changes from different developers can be challenging, leading to integration conflicts. 

3. In case of issues with a release, rollbacks can be challenging and time-consuming. 

4. Developers may face issues when deploying code to different environments due to inconsistencies in configuration.

5. Monitoring required to identify the problem or service status and resolve it quickly.

6. Customers were not getting real-time insights into the health and performance of systems and applications,so mostly they received problems facing mail through users.

7. Problem solving was taking time because manually checking the cause of the problem will take time.

8. Users require monitoring the resources allocated across different components of the setup. This information helps in optimising resource distribution and avoiding resource conflicts.

9. Users want to handle the scaling and load balancing of containers and ensure high availability of applications.

10. User wants pod scaling management itself as per the application load.

11. Haproxy  setup required with Custom rule in configuration for managing high load of users.

12. Postgres upgrade for better database performance.

<span style="color:grey">
Problem Statement:</span>

1. Manual war deployments are often slow and infrequent due to time-consuming manual testing and deployment processes.

2. In larger development teams, integrating code changes from different developers can be challenging, leading to integration conflicts. 
3. In case of issues with a release, rollbacks can be challenging and time-consuming.

4. Developers may face issues when deploying code to different environments due inconsistencies in configuration. 

#### Solutions:

**CI/CD is a modern DevOps practice that involves automating the build, testing, and deployment of code changes. Here are some key benefits of implementing CI/CD at the client setup:**

1. **Faster and More Frequent Releases:** CI/CD pipelines automate the build, test, and deployment processes, allowing developers to release new features and updates more frequently and with greater confidence. This leads to faster delivery of software to end-users and a competitive edge in the market.

2. **Improved Code Quality:** With automated testing in CI/CD pipelines, code changes are thoroughly tested before deployment. This helps catch bugs and issues early in the development process, leading to higher code quality and more stable releases.

3. **Reduced Manual Errors:** Automating the build and deployment process reduces the chances of human errors that might occur when performing these tasks manually. This leads to more reliable and consistent releases.

4. **Increased Collaboration:** CI/CD encourages collaboration between developers, testers, and operations teams. The automated pipeline provides visibility into the status of builds and deployments, fostering better communication and coordination among team members.

5. **Time and Cost Savings:** By automating repetitive tasks, CI/CD reduces the time and effort required for manual processes, saving both time and costs associated with development and deployment.

In summary, implementing CI/CD at the client setup offers numerous advantages, including faster releases, improved code quality, reduced errors, better collaboration, cost savings, and a more reliable and scalable development process. It empowers teams to deliver software more efficiently and with higher confidence, leading to increased customer satisfaction and business success.

<span style="color:grey">
Screenshot for deployment (CICD)
</span>


![Alt text](NSP1.1.png)

**<span style="color:grey">
Monitoring Setup for all servers:
</span>**

**- DB servers(connection count/load/Materialised view/backup status).**

**- Haproxy servers(load/instances status/count request).**

**- OCP servers(load/machine status).**

**- API servers(load/instance status/api performance status).**


<span style="color:grey">Problems: </span>

**- Monitoring required to identify the problem or service critical status and resolve it quickly.**

**- Customers were not getting real-time insights into the health and performance of systems and applications, so mostly they received problems facing mail through users.**

**- Problem solving was taking time because manually checking the cause of the problem will take time.**

**- Users require monitoring the resources allocated across different components of the setup. This information helps in optimising resource distribution and avoiding resource conflicts.**

**Nagios and Grafana are powerful monitoring tools** used by organizations to keep a close eye on their IT infrastructure, applications, and services. When combined, they offer a comprehensive monitoring and visualization solution. Please find below:

**1. Comprehensive Monitoring:** Nagios is a robust monitoring system that allows you to monitor various aspects of your infrastructure, such as servers, network devices, services, and applications. 

**2. Real-time Alerting:** Nagios provides proactive monitoring with real-time alerting. When an issue or service degradation occurs, Nagios can send alerts via email, SMS, or other communication channels, enabling IT teams to respond promptly and prevent downtime.

**3. Centralized Dashboard:** Grafana is a powerful data visualization tool that can integrate with Nagios. By setting up Grafana alongside Nagios, you can create centralized dashboards that display real-time data from Nagios checks and other data sources. This makes it easier for IT teams to monitor and troubleshoot issues efficiently.

**4. Customizable Dashboards:**
 Grafana offers a wide range of visualization options and customization features.

**5. Historical Data Analysis:** Grafana allows you to store historical monitoring data, enabling you to analyze trends and identify patterns over time.

**6. Integration with Multiple Data Sources:** Grafana supports integration with various data sources, including databases, cloud platforms, and other monitoring systems. 

**7. User-friendly Interface:** Grafana's user-friendly and intuitive interface makes it easy for both technical and non-technical users to access and understand monitoring data. This promotes collaboration among teams and enables stakeholders to stay informed.

**8. Scalability:** Nagios and Grafana are highly scalable, making them suitable for monitoring small to large-scale infrastructures. Whether you have a few servers or a complex distributed environment, this setup can handle your monitoring needs.
**9.Cost-Effectiveness:** Both Nagios and Grafana are open-source solutions, which means you can set them up without significant licensing costs. This makes the combination a cost-effective option for organizations with budget constraints.

In summary, setting up Nagios and Grafana together offers a robust monitoring and visualization solution that helps organizations maintain the health and performance of their IT infrastructure and services. With real-time alerting, historical data analysis, and customizable dashboards, IT teams can respond proactively to issues and make data-driven decisions to optimize their systems and services.


Screenshot:
 	 	
**<span style="color:grey">Postgres counts monitoring along with server performance:
</span>**

![Alt text](NSP1.png)

**<span style="color:grey">Servers and services monitoring through nagios:
</span>**	 	

![Alt text](NSP2.png)

Materialised views must be refreshed on a daily basis for updated data on the website, so we have set monitoring of MV status in the grafana tool.

![Alt text](NSP3.png)


APIs need to be monitor as per client requirement, which have set in grafana.

![Alt text](NSP4.png)

Servers monitoring in grafana:

![Alt text](NSP5.png)

**Problems:**

Users want to handle the scaling and load balancing of containers and ensure high availability of applications.
User wants pod scaling management itself as per the application load.

**OCP Setup:**



OCP, which stands for OpenShift Container Platform, is a Kubernetes-based enterprise container platform developed by Red Hat. It provides a comprehensive set of tools and features for deploying, managing, and scaling containerized applications. The platform offers several benefits for organizations looking to adopt containerization and cloud-native development practices. Here are some key benefits of OCP:

**1. Simplified Application Deployment:**
OCP abstracts the complexities of container orchestration and provides a streamlined way to deploy applications in containers. It automates the deployment process, making it easier and faster to bring applications into production.

**2. Scalability:** 
OCP allows applications to scale both vertically and horizontally. It can automatically scale applications based on demand, ensuring optimal performance and resource utilization.

**3. Container Management:**
OCP provides tools to manage container lifecycles, including rolling updates, rollbacks, and automatic healing of containers. This ensures high availability and reduces downtime during updates or failures.

**4. DevOps Enablement:**
OCP fosters collaboration between development and operations teams by providing a shared platform and consistent environments for building, testing, and deploying applications.This accelerates the DevOps process.

**5. Application Portability:**
 Containers deployed on OCP are highly portable. Developers can build once and deploy anywhere, whether it's on the local development environment, staging environment, or production environment.

**6. Monitoring and Logging:** OCP offers built-in monitoring and logging capabilities to gain insights into application performance and troubleshoot issues effectively.


Overall, OCP empowers organizations to embrace containerization, microservices, and cloud-native architectures while providing a robust platform for managing containerized applications at scale. It enables faster application development, deployment, and iteration, driving innovation and efficiency in modern software development practices.


**<span style="color:grey">Screenshot</span>**

![Alt text](NSP6.png)

**<span style="color:grey">Problems</span> :** 
Users require interactive dashboards and visualisations based on data in database, which can present on kibana.

User wants to visualise structured and unstructured data as per requirement.
Users were not able to represent dashboards on the real-or-live based data.

**Elasticsearch** is a powerful and widely-used open-source search and analytics engine. It is built on top of Apache Lucene and is designed to handle large-scale data processing, search, and analysis. Elasticsearch offers a wide range of benefits, making it a popular choice for various applications and use cases.
 Here are some key benefits of Elasticsearch:

**1. Full-text Search:** Elasticsearch provides highly efficient full-text search capabilities, allowing users to perform complex text-based searches across vast amounts of data. It supports fuzzy matching, stemming, autocomplete, and various search features, making it ideal for applications that require sophisticated search functionality.

**2. Real-time Data Indexing:** Elasticsearch excels at real-time indexing and analysis of data. It can ingest, index, and make data available for search and analysis in near real-time, enabling quick insights and decision-making.

**3. Scalability and High Availability:** Elasticsearch is designed to be distributed and scalable. It can easily handle large datasets and can be clustered to ensure high availability and fault tolerance. This makes it suitable for applications with high traffic and demanding workloads.

**4. JSON-based Documents:** Elasticsearch stores data in JSON format, which is widely used and easy to work with. JSON documents allow for flexible and dynamic schema mapping, making it adaptable to changing data structures.

**5. Aggregation and Analytics:** Elasticsearch supports various aggregation features, allowing users to perform complex analytics and aggregations on the indexed data. It enables real-time data exploration and visualization, making it useful for business intelligence and data analytics applications.

**6. Near Real-time Analytics:**

 With its ability to handle real-time data and powerful query capabilities, Elasticsearch is well-suited for near real-time analytics and monitoring applications. It enables users to track and analyze trends and anomalies as they happen.

**7. RESTful API :**
 Elasticsearch provides a simple RESTful API, making it easy to interact with the system using standard HTTP methods. This API allows for easy integration with other applications and frameworks.

 **8. Open-source and Active Community:** Being open-source,Elasticsearch is freely available for use and has a vibrant and active community. This community continuouslycontributes to the platform's development,documentation, and support.

**9. Multi-language Support:** Elasticsearch supports multiple programming languages through client libraries, making it accessible to developers from various language ecosystems.

**10. Integration with the Elastic Stack:** Elasticsearch is a core component of the Elastic Stack, which includes Kibana (for visualization), Logstash (for data collection and processing), and Beats (for data shippers). This integration allows users to build end-to-end data pipelines for data ingestion, search, analytics, and visualization.

In summary, Elasticsearchoffers a robust and flexible search and analytics engine that excels in handling real-time data, search queries, and aggregations. Its scalability, high availability,and ease of use make it an excellent choice for a wide range of applications,including search engines, logging and monitoring systems, e-commerce platforms, and data analytics solutions.

**Screenshot:**

![Alt text](NSP7.png)

![Alt text](NSP8.png)


**Problems:** Customer requires API gateway for security at the time of api access with authentication.

Request and response count detail required for understanding the requirement.
User request loads also need to be monitored.


**APIsix** is a high-performance and scalable open-source API gateway that is designed to handle and manage API traffic in a distributed and efficient manner. It provides various features and functionalities that make it suitable for solving specific problems and use cases. Some of the scenarios where APIsix excels as the best tool include:

**1. Microservices Architecture:** APIsix is well-suited for managing API requests and responses in a microservices-based architecture. It acts as a centralized entry point to handle incoming requests and efficiently route them to the appropriate microservices.

**2. Load Balancing:**
 APIsix can perform load balancing across multiple backend servers or microservices instances, ensuring optimal distribution of incoming API traffic to maintain high availability and performance.

**3. Security and Authentication:** APIsix provides various security features, such as API key authentication, JWT verification, and SSL termination, to ensure secure communication between clients and backend services.

**4. Caching:**  It supports caching responses from backend services, reducing the load on downstream systems and improving response times for frequently requested data.

**5. Logging and Monitoring:**
 APIsix can generate detailed logs of API traffic, helping with monitoring, analytics, and debugging.

**6. Analytics and Metrics:**  The gateway can collect and report API usage metrics, enabling you to gain insights into API performance and usage patterns.

**7. Service Discovery and Health Checks:**
 APIsix integrates with service discovery mechanisms and performs health checks to ensure backend services are available and healthy.

**8. API Versioning:**  It allows you to manage different versions of your APIs and handle version-specific requests effectively.


APIsix is an excellent choice for organizations that require a powerful and flexible API gateway to manage, secure, and optimize their API traffic. It is particularly well-suited for cloud-native and microservices-based applications where scalability, performance, and reliability are crucial.

**Screenshot:**

![Alt text](NSP9.png)


**PostgreSQL setup upgrade latest version:**

<span style="color:grey">PostgreSQL, often referred to as Postgres, is a powerful open-source relational database management system (RDBMS). It is known for its advanced features, extensibility, and compliance with SQL standards.</span>

 PostgreSQL supports a wide range of data types, indexing methods, and procedural languages, making it a popular choice for various applications, from small-scale projects to large-scale enterprise systems.

![Alt text](NSP10.png)


**<span style="color:grey">HAProxy (High Availability Proxy)</span>** <span style="color:grey">is a free and open-source load balancer and proxy server software that is widely used to distribute incoming application traffic across multiple backend servers or nodes.</span>
It offers several benefits, making it a popular choice for improving the performance, reliability, and scalability of web applications. Some of the key benefits of HAProxy include:

![Alt text](NSP11.png)



