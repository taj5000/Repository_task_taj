# <p style="text-align: center; font-family: 'Times New Roman', serif;"><font size="10">Crunchy-Postgres-Exporter</p>

</br>

<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="6">1. Task requirement:</font>

  <p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4"> To set up Postgres exporter which capture the slow query also.</font> 

<p style="text-align: left; font-family: 'Times New Roman', serif;"><font size="4">The crunchy-postgres-exporter container provides real time metrics about the PostgreSQL database via an API. These metrics are scraped and stored by a Prometheus time-series database and are then graphed and visualized through the open source data visualizer Grafana.</font>



<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="6">2. Environment details:</font>

* <p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4">Podman - Version 3 . </font></p>



<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="6">3. List of tools and technologies: </font></p>

* <p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4"> Podman Version-12 </font></p>


* <p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4"> Postgres version -12 </font></p>

  </br>

<div style="page-break-after: always;"></div>

<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="6">a. Definition of Podman</font></p>


<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4">Podman (the POD manager) is an open source tool for developing, managing, and running containers on your Linux systems. Originally developed by Red Hat® engineers along with the open source community, Podman manages the entire container ecosystem using the libpod library.</font></p>

  </br>

<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="6">b. Definition of PostgreSQL</font></p>

<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4">PostgreSQL, also known as Postgres, is a free and open-source relational database management system emphasizing extensibility and SQL compliance. It was originally named POSTGRES, referring to its origins as a successor to the Ingres database developed at the University of California, Berkeley.</font></p>

  </br>

<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="6">4. Command for the setup or configuration: </font></p>

  </br>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">1. Create Pod: </font></p>** 

> <font size="4">podman pod create --name crunchy-postgres --publish 9090:9090 --publish 9187:9187 --publish 5432:5432 --publish 3000:3000 </font>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">2. Create Postgres container:</font></p>** 


> <font size="4">podman run -d --pod crunchy-postgres --name postgres_crunchy -e "POSTGRES_DB=postgres" -e "POSTGRES_USER=postgres" -e "POSTGRES_PASSWORD=redhat" -v 
/home/yogendra/shiksha_portal/crunchy/postgres/data:/var/lib/postgresql/data docker.io/postgres:12</font> 

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">3. Do Changes in configuration file:</font></p>**

> <font size="4">echo "shared_preload_libraries = 'pg_stat_statements,auto_explain'" >> postgresql.conf</font> 

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
<font size="5">4. Pull crunchy-postgres-exporter image:</font></p>** 

> <font size="4">podman pull 
registry.connect.redhat.com/crunchydata/crunchy-postgres-exporter:latest</font> 

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">5. Create a demo container of crunchy for setup.sql.</font></p>** 

> <font size="4">podman run -itd --pod crunchy-postgres --name crunchy -e 
EXPORTER_PG_PASSWORD=redhat 615904c619c5</font> 

<div style="page-break-after: always;"></div>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">6. Get the setup.sql from /opt/cpm/conf/pgxx/setup.sql from the crunchy container according to your postgres version.</font></p>**

> <font size="4">podman cp crunchy:/opt/cpm/conf/pg12/setup.sql</font>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">7. Remove the test container of crunchy:</font></p>** 

> <font size="4">podman rm -f crunchy </font>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">8. Push setup.sql in postgres database:</font></p>** 

<font size="5">Get the setup.sql from /opt/cpm/conf/pg12/setup.sql from the exporter container.</font>

> <font size="4">psql -h 127.0.0.1 -U postgres -d template1 < setup.sql</font> 

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">9. Create Extension:</font></p>** 

> <font size="4">psql -h 127.0.0.1 -U postgres -d template1 -c "CREATE EXTENSION pg_stat_statements;"</font>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">10. Create password for user ccp_monitoring:</font></p>**

> <font size="4">postgres=# \password ccp_monitoring</font> 

> <font size="4">Enter new password for user "ccp_monitoring":</font> 

<div style="page-break-after: always;"></div>


<font size="4">Enter it again:</font>

> <font size="4">postgres=# create database yogendra;</font> 

> <font size="4">CREATE DATABASE </font>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">11. Now create crunchy-postgres-exporter container:</font></p>**

> <font size="4">podman run -itd --pod crunchy-postgres --name crunchy -e 
EXPORTER_PG_PASSWORD=redhat -e EXPORTER_PG_HOST=127.0.0.1 -e EXPORTER_PG_USER=ccp_monitoring -e 
DATA_SOURCE_NAME=postgresql://ccp_monitoring:redhat@127.0.0.1:5432/yo gendra?sslmode=disable 615904c619c5</font> 

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">12. Check metrics:</font></p>** 

> <font size="4">curl localhost:9187/metrics | grep query </font>

**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">13. Create prometheus container:<font></p>**

> <font size="4"> podman run -itd --pod crunchy-postgres --name prometheus_crunchy -v /home/yogendra/shiksha_portal/prometheus_crunchy/prometheus.yml:/etc/pro metheus/prometheus.yml docker.io/prom/prometheus</font>

> <font size="4">Set the target in prometheus.yml file to get metrics in prometheus and hit on browser: http://localhost:9091/</font>


![Alt text](C1.png)

![Alt text](C2.png)



**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">14. Create Grafana Container:</font></p>** 

> <font size="4">podman run -itd --pod crunchy-postgres --name grafana_crunchy
docker.io/grafana/grafana 


Hit on browser: 

> http://localhost:3000/ 
Select the prometheus as a datasource and import the dashboard.
9628

![Alt text](C3.png)



**Test cases list**

</br>

![Alt text](C4.png)





<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="4">Note : NA</font></p>


**<p style="text-align: left; font-family: 'Times New Roman', serif;">
  <font size="5">Reference link</font></p>**

https://access.crunchydata.com/documentation/pgmonitor/2.2/exporter/index.html 

